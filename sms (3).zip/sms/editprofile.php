<?php
include 'conn.php';
session_start();
$id=$_SESSION['uname'];
echo $id;
$result ="SELECT * FROM reg where uncod='$id'";
$result3=mysqli_query($con,$result);
while($row3 = mysqli_fetch_array($result3))
{ 
$fname=$row3['fname'];
$lname=$row3['lname'];
//$gender=$row3['gender'];
//$dob=$row3['dob'];
$phone=$row3['phone'];
$mobile=$row3['mobile'];
//$email=$row3['email'];
$hname=$row3['hame'];
//$city=$row3['cityid'];
$pincode=$row3['pincode'];
}
?>
<!DOCTYPE html>

<html lang="en">
  <head>
    <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
    ====================================================-->

    <!-- Basic Page Needs
    ================================================== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <title>WpF Degree : Home</title>

    <!-- Mobile Specific Metas
    ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/icon" href="img/wpf-favicon.png"/>

    <!-- CSS
    ================================================== -->       
    <!-- Bootstrap css file-->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Font awesome css file-->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- Superslide css file-->
    <link rel="stylesheet" href="css/superslides.css">
    <!-- Slick slider css file -->
    <link href="css/slick.css" rel="stylesheet"> 
    <!-- Circle counter cdn css file -->
    <link rel='stylesheet prefetch' href='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/css/jquery.circliful.css'>  
    <!-- smooth animate css file -->
    <link rel="stylesheet" href="css/animate.css"> 
    <!-- preloader -->
    <link rel="stylesheet" href="css/queryLoader.css" type="text/css" />
    <!-- gallery slider css -->
    <link type="text/css" media="all" rel="stylesheet" href="css/jquery.tosrus.all.css" />    
    <!-- Default Theme css file -->
    <link id="switcher" href="css/themes/default-theme.css" rel="stylesheet">
    <!-- Main structure css file -->
    <link href="style.css" rel="stylesheet">
   
    <!-- Google fonts -->
    <link href='http://fonts.googleapis.com/css?family=Merriweather' rel='stylesheet' type='text/css'>   
    <link href='http://fonts.googleapis.com/css?family=Varela' rel='stylesheet' type='text/css'>    

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </head>
  <body>    

    <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <!--=========== BEGIN HEADER SECTION ================-->
    <header id="header">
      <!-- BEGIN MENU -->
      <div class="menu_area">
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation">  <div class="container">
            <div class="navbar-header">
              <!-- FOR MOBILE VIEW COLLAPSED BUTTON -->
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <!-- LOGO -->
              <!-- TEXT BASED LOGO -->
              <a class="navbar-brand" href="index.html">WpF <span>college</span></a>              
              <!-- IMG BASED LOGO  -->
               <!-- <a class="navbar-brand" href="index.html"><img src="img/logo.png" alt="logo"></a>  -->            
                     
            </div>
             <div id="navbar" class="navbar-collapse collapse">
              <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
                <li class="active"><a href="index.php">Home</a></li>
            
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Register<span class="caret"></span></a>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="studreg.php">Student Register</a></li>
                    <li><a href="teacherreg.php">Teacher Register</a></li>               
                  </ul>
                </li>               
                <li><a href="login.php">Login</a></li>
              </ul>           
            </div><!--/.nav-collapse -->
          </div>     
        </nav>  
      </div>
      <!-- END MENU -->    
    </header>
	
	<script>

        function tPhone(){
            var mobile=document.edetails.mobile.value;
                if(isNaN(mobile)){
                    
                    alert("Phone Number Only Contain Digits");
                    document.edetails.mobile.focus();
                    return false;
                }
                if(mobile.length !== 10){
                    document.edetails.mobile.focus();
                    alert("Phone Number must be 10 Digits");
                    
                    return false;
                }
        }
		function tPin(){
            var pin=document.edetails.pin.value;
                if(isNaN(pin)){
                    
                    alert("Pincode Only Contain Digits");
                    document.edetails.pin.focus();
                    return false;
                }
                if(pin.length !== 6){
                    document.edetails.pin.focus();
                    alert("Pincode must be 6 Digits");
                    
                    return false;
                }
        }
		function fName(){
            
                var fname=/^[a-zA-Z ]/;
                if(document.edetails.fname.value.search(fname)==-1)
                 {
                      alert("First name must contain alphabets only ");
                      document.edetails.fname.focus();
                      
                      return false;
                    }

        }
		function lName(){
           
                var lname=/^[a-zA-Z ]/;
                if(document.edetails.lname.value.search(lname)==-1)
                 {
                      alert("last name must contain alphabets only");
                      document.edetails.lname.focus();
                      
                      return false;
                    }
                
        }
		function hName(){
           
                var hname=/^[a-zA-Z ]/;
                if(document.edetails.hname.value.search(hname)==-1)
                 {
                      alert("House name must contain alphabets only");
                      document.edetails.hname.focus();
                      
                      return false;
                    }
                
        }
		function lPhone(){
            var phone=document.edetails.phone.value;
                if(isNaN(phone)){
                    
                    alert("Phone Number Only Contain Digits");
                    document.edetails.phone.focus();
                    return false;
                }
				if(phone.length !==11 ){
                    document.edetails.phone.focus();
                    alert("Phone Number must be 11 Digits with specific code");
                    
                    return false;
                }
		}
		 
        
   function valid()
{
	
 if(document.edetails.fname.value=="")
  {
     alert("enter name");
	 document.edetails.fname.focus();
	 return false;
  }
  if(!document.edetails.fname.value.match(/^[a-z A-Z]+$/))
  {
     alert("alphabets only");
	 document.edetails.fname.focus();
	 return false;
   }
	 if(!document.edetails.lname.value.match(/^[a-z A-Z]+$/))
   {
      alert("alphabets only");
 	 document.edetails.lname.focus();
 	 return false;
    }
   
	 if(document.edetails.mobile.value=="")
   {
      alert("enter your mobile number");
	 document.edetails.mobile.focus();
	 return false;
	}
	if(isNaN(document.edetails.mobile.value))
    {
     alert("using only numbers");
	 document.edetails.mobile.focus();
	 return false;
   }
   var mobile=document.edetails.mobile.value;
   if(mobile.length!=10)
   {
     alert("mobile number contain 10 digit");
		 document.edetails.mobile.focus();
	 return false;
	}
	
	if(isNaN(document.edetails.pin.value))
		{
		 alert("using only numbers");
	 document.edetails.pin.focus();
	 return false;
	 }

	
	 if(!document.tregister.hname.value.match(/^[a-z A-Z]+$/))
   {
      alert("alphabets only");
 	 document.tregister.hname.focus();
 	 return false;
    }
		
}
</script>
<form  action="#" onsubmit="return" name="edetails" id="" method="post" enctype="multipart/form-data" onsubmit="return valid()">
<table width="300" height="300"  align="center">
<caption><h2>Edit Profile</h2></caption>
</tr>
  <!--<tr>
    <td></td><td><img src="<?php echo $img ?>" style="border-radius: 50%;position:absolute;right:900px;" width="150px" height="150px" alt="no image found"/></td></tr>-->
    <tr<tr><td width="82" valign="top"><div align="left">Firstname:</div></td>
    <td width="165" valign="top"><input type="text" name="fname" id="fname" value='<?php echo $fname ?> 'onChange="return fName()"></td>
  </tr>
  <tr>
    <td valign="top"><div align="left">Lastname:</div></td>
    <td valign="top"><input type="text" name="lname" id="lname" value='<?php echo $lname ?> ' onChange="return lName()"></td>
  </tr>
 <!-- <tr>
    <td valign="top"><div align="left">Gender:</div></td>
    <td valign="top"><input type="text" name="gender" value='<?php echo $gender ?> '></td>
  </tr>
  <tr>
    <td valign="top"><div align="left">Date of Birth: </div></td>
    <td valign="top"><input type="text" name="dob" value='<?php echo $dob ?> '></td>
  </tr>-->
  <tr>
    <td valign="top"><div align="left">Phone: </div></td>
    <td valign="top"><input type="text" name="phone" value='<?php echo $phone ?> 'onChange="return lPhone()"></td>
  </tr>
  <tr>
    <td valign="top"><div align="left">Mobile: </div></td>
    <td valign="top"><input type="text" name="mobile" value='<?php echo $mobile ?> 'onChange="return tPhone()"></td>
  </tr>
 <!-- <tr>
   <td valign="top"><div align="left">Email:</div></td>
    <td valign="top"><input type="email" name="email" value='<?php echo $email ?> ' onChange="return tEmail()"></td>
  </tr>--> 
  <tr>
    <td valign="top"><div align="left">Housename: </div></td>
    <td valign="top"><input type="text" name="hname" value='<?php echo $hname ?> ' onChange="return hName()"></td>
  </tr>
   
  <!--<tr>
    <td valign="top"><div align="left">State: </div></td>
    <td valign="top"><input type="text" name="state" id="state" value='<?php echo $state1 ?> '></td>
  </tr>
  <tr>
    <td valign="top"><div align="left">District: </div></td>
    <td valign="top"><input type="text" name="district" value='<?php echo $district1 ?> '></td>
  </tr>
  <tr>
    <td valign="top"><div align="left">City: </div></td>
    <td valign="top"><input type="text" name="city" value='<?php echo $city1 ?> '></td>
  </tr>-->
  <tr>
    <td valign="top"><div align="left">Pincode: </div></td>
    <td valign="top"><input type="text" name="pincode" value='<?php echo $pincode ?> 'onChange="return tPin()"></td>
  </tr>
  <td><center><input type="submit" name="submit"  value="EditProfile" class="button"></center></td>
  </td></tr>
</table></form>

<?php
if(isset($_POST['submit']))
{
//$b=$_POST['drop'];
$fname=$_POST["fname"];
$lname=$_POST["lname"];
//$gender=$_POST["gender"];
//$dob=$_POST["dob"];
$phne=$_POST["phne"];
//$email=$_POST["email"];
$hname=$_POST["hname"];
//$city=$_POST["cityid"];
$pincode=$_POST["pincode"];
$mobile=$_POST["mobile"];

$res=mysqli_query($con,"UPDATE `reg` SET `fname`='$fname',`lname`='$lname',`phone`='$phne',mobile='$mobile',`hame`='$hname',`pincode`='$pincode'  WHERE `uncod`='$id'");
echo "<script>alert('sucessfully updated')</script>";
}?>  
</body>
</html><?php ?>
