<?php
include_once 'conn.php'; //database connection page
$uncod=$_GET['id'];;
//echo $houseno;
$sql="UPDATE `reg` SET `status`='1' WHERE `uncod`='$uncod'";
$result=mysqli_query($con,$sql);
header("location:teacherview.php");
?>
