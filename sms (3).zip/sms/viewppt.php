<html>
<head></head>
<body>
<?PHP
include 'conn.php';
$a=$_GET['id'];
echo $a;
$results=mysqli_query($con,"SELECT note FROM `notes` WHERE noteid='$a'");
while($row=mysqli_fetch_array($results))
{
?>
<form name="myform"  method="post">
		<div class="wrap"> <object width="1500"  height="1000" data="<?php echo $row['note'];?>"/>
          
        </div>
		</form>

<?php } ?>
</body>
</html>
