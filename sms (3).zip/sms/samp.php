<!DOCTYPE html>
<html lang="en">
<head>
<title>Student portal | register</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<link rel="stylesheet" href="css/saps.css" type="text/css">
<script type="text/javascript" src="js/jquery-1.5.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Molengo_400.font.js"></script>
<script type="text/javascript" src="js/Expletus_Sans_400.font.js"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="js/html5.js"></script>
<style type="text/css">.bg, .box2{behavior:url("js/PIE.htc");}</style>
<![endif]-->
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body id="page2">
<div class="body1">
  <div class="main">
    <!-- header -->
    <header>
      <div class="wrapper">
        <nav>
          <ul id="menu">
            <li><a href="teacher.php">Home</a></li>
           <li class="dropdown">
      <a href="#" class="dropbtn">Marks</a>
      <div class="dropdown-content">
	  <a href="marks.php">Add Marks</a>
<a href="viewedmark.php">View Marks</a>
</ul></nav>
        <ul id="icons">
          <li><a href="#"><img src="images/icons1.jpg" alt=""></a></li>
          <li><a href="#"><img src="images/icons2.jpg" alt=""></a></li>
        </ul>
      </div>
      <div class="wrapper">
        <h1><a href="index.php" id="logo">Learn Center</a></h1>
      </div>
      <div id="slogan"> We Will Open The World<span>of knowledge for you!</span> </div>
    </header>
    <!-- / header -->
  </div>
</div>
<div class="body2">
  <div class="main">
    <!-- content -->
    <section id="content">
      <div class="box1">
        <div class="wrapper">
          <article class="col1">
            <div class="pad_left1">
              <h2 class="pad_bot1"><b>Marks</b></h2>
            </div>
            
    <!-- content -->
    <form  action="" method="post" >
    <center>


<h4>Please enter the Branch</h4>
 <br>

<input type="text" name="branch"> <br>
<h4>Please enter the semester</h4>
<br>
<input type="text" name="semester"> <br>
		<br>
		<br>
        <input type="submit" name="submit" value="Search">

</form><br>
<br>
<br>
<center>

<div>
<table cellpadding="10"height="200" width="250">
<tr>
<td>
<label>Subject</label></td>
<td>
<select name="sub" id="subj">
<?php
include 'conn.php';
if(isset($_POST["submit"]))
{
$b=$_POST['branch'];
$c=$_POST['semester'];
    $results=mysqli_query($con,"select subject from subject where branch='$b' and semester='$c'");
  while($row=mysqli_fetch_array($results))
  {
	  ?>
	  <option name="<?php echo $row['subject']; ?>"><?php echo $row['subject']; ?></option>

<?php

}
}
?>
</select>
</td>
</tr>
</div>
</table>
<div id="markdetail">
</div>
<script>
$('body').on('change', '#subj', function () {
          $find = $('#subj').val();
          alert($find);
            $.ajax({
            type:'post',
                    url:'markdata.php',
                    data:{index:$find},
                    success:function(response)
                    {                  
                    $('#markdetail').html(response);
                }
                    });

    });

						
</script>
</body>
</html>
