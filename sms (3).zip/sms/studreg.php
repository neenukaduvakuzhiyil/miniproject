<?php
include 'conn.php';
if(isset($_POST['submit']))
{
$s=$_POST['adno'];
$w=$_POST['fname'];
$a=$_POST['lname'];
//$image=$_POST['timg'];
$b=$_POST['dob'];
$c=$_POST['gender'];
$d=$_POST['phone'];
$e=$_POST['mobile'];
$f=$_POST['email'];
$g=$_POST['hname'];
$h=$_POST['place_select'];
$i=$_POST['pin'];
$j=$_POST['branch'];
$z=$_POST['sem'];
$k=$_POST['pword'];
$t=SHA1($k);
$l=$_POST['cpword'];
$q=SHA1($l);
if($t!=$q)
{
	echo "<script>alert('Please check your passwords mismatch occured')</script>" ;
}
else
{
$sql2="select * from reg where uncod='$s'";
$result2=mysqli_query($con,$sql2);
if($res=mysqli_fetch_array($result2))
{
echo "<script>alert('Please check your admission number')</script>" ;
}
else
{
	
$sql="INSERT INTO `reg`(`uncod`,`fname`, `lname`, `dob`,  `gender`, `phone`, `mobile`, `email`, `hame`, `cityid`, `pincode`, `branch`, `semester`, `roles`) 
VALUES ('$s','$w','$a','$b','$c','$d','$e','$f','$g','$h','$i','$j','$z','0')";


$result=mysqli_query($con,$sql);
$sql1="INSERT INTO `login`( `username`, `password`, `role`) VALUES ('$s','$t','0')";

$result1=mysqli_query($con,$sql1);
echo "<script>alert('Registered successfully')</script>" ;
}
}}
?>
<!DOCTYPE html>

<html lang="en">
  <head>
    <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
    ====================================================-->

    <!-- Basic Page Needs
    ================================================== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <title>WpF Degree : Home</title>

    <!-- Mobile Specific Metas
    ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/icon" href="img/wpf-favicon.png"/>

    <!-- CSS
    ================================================== -->       
    <!-- Bootstrap css file-->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Font awesome css file-->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- Superslide css file-->
    <link rel="stylesheet" href="css/superslides.css">
    <!-- Slick slider css file -->
    <link href="css/slick.css" rel="stylesheet"> 
    <!-- Circle counter cdn css file -->
    <link rel='stylesheet prefetch' href='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/css/jquery.circliful.css'>  
    <!-- smooth animate css file -->
    <link rel="stylesheet" href="css/animate.css"> 
    <!-- preloader -->
    <link rel="stylesheet" href="css/queryLoader.css" type="text/css" />
    <!-- gallery slider css -->
    <link type="text/css" media="all" rel="stylesheet" href="css/jquery.tosrus.all.css" />    
    <!-- Default Theme css file -->
    <link id="switcher" href="css/themes/default-theme.css" rel="stylesheet">
    <!-- Main structure css file -->
    <link href="style.css" rel="stylesheet">
   
    <!-- Google fonts -->
    <link href='http://fonts.googleapis.com/css?family=Merriweather' rel='stylesheet' type='text/css'>   
    <link href='http://fonts.googleapis.com/css?family=Varela' rel='stylesheet' type='text/css'>    

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </head>
  <body>    

    <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <!--=========== BEGIN HEADER SECTION ================-->
    <header id="header">
      <!-- BEGIN MENU -->
      <div class="menu_area">
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation">  <div class="container">
            <div class="navbar-header">
              <!-- FOR MOBILE VIEW COLLAPSED BUTTON -->
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <!-- LOGO -->
              <!-- TEXT BASED LOGO -->
              <a class="navbar-brand" href="index.html">WpF <span>college</span></a>              
              <!-- IMG BASED LOGO  -->
               <!-- <a class="navbar-brand" href="index.html"><img src="img/logo.png" alt="logo"></a>  -->            
                     
            </div>
             <div id="navbar" class="navbar-collapse collapse">
              <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
                <li><a href="index.php">Home</a></li>
            
                <li  class="active" class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Register<span class="caret"></span></a>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="studreg.php">Student Register</a></li>
                    <li><a href="teacherreg.php">Teacher Register</a></li>               
                  </ul>
                </li>               
                <li><a href="login.php">Login</a></li>
              </ul>           
            </div><!--/.nav-collapse -->
          </div>     
        </nav>  
      </div>
      <!-- END MENU -->    
    </header>
	<script>
function sEmail(){
            var email=document.sregister.email.value;
                var atpos = email.indexOf("@");
                var dotpos = email.lastIndexOf(".");
                if((atpos<1)||(dotpos<atpos+2)||(dotpos+2>email.length)){
                    
                    document.sregister.email.focus();
                    alert("Enter a Valid Email Address");
                    return false;
                }
        }
        function sPhone(){
            var mobile=document.sregister.mobile.value;
                if(isNaN(mobile)){
                    
                    alert("Phone Number Only Contain Digits");
                    document.sregister.mobile.focus();
                    return false;
                }
                if(mobile.length !== 10){
                    document.sregister.mobile.focus();
                    alert("Phone Number must be 10 Digits");
                    
                    return false;
                }
        }
		function hName(){
           
                var hname=/^[a-zA-Z ]/;
                if(document.tregister.hname.value.search(hname)==-1)
                 {
                      alert("House name must contain alphabets only");
                      document.tregister.hname.focus();
                      
                      return false;
                    }
                
        }
		function sPin(){
            var pin=document.sregister.pin.value;
                if(isNaN(pin)){
                    
                    alert("Pincode Only Contain Digits");
                    document.sregister.pin.focus();
                    return false;
                }
                if(pin.length !== 6){
                    document.sregister.pin.focus();
                    alert("Pincode must be 6 Digits");
                    
                    return false;
                }
        }
		function fName(){
            
                var fname=/^[a-zA-Z ]/;
                if(document.sregister.fname.value.search(fname)==-1)
                 {
                      alert(" Name must alphabets ");
                      document.sregister.fname.focus();
                      
                      return false;
                    }
                
        }
		function lName(){
            
                var lname=/^[a-zA-Z ]/;
                if(document.sregister.lname.value.search(lname)==-1)
                 {
                      alert("  Name must alphabets");
                      document.sregister.lname.focus();
                      
                      return false;
                    }
                
        }
		function lPhone(){
            var phone=document.sregister.phone.value;
                if(isNaN(phone)){
                    
                    alert("Phone Number Only Contain Digits");
                    document.sregister.phone.focus();
                    return false;
                }
				if(phone.length !==11 ){
                    document.sregister.phone.focus();
                    alert("Phone Number must be 11 Digits with specific code");
                    
                    return false;
                }
		}
		 function sAdmNo(){
             var adno=document.sregister.adno.value;
                if(isNaN(adno)){
                    
                    alert("Roll number Only Contain Digits");
                    document.sregister.adno.focus();
                    return false;
                }
				
        }
   function valid()
{
	if(isNaN(document.sregister.adno.value))
    {
     alert("using only numbers");
	 document.sregister.adno.focus();
	 return false;
   }
 if(document.sregister.fname.value=="")
  {
     alert("enter name");
	 document.sregister.fname.focus();
	 return false;
  }
  if(!document.sregister.fname.value.match(/^[a-z A-Z]+$/))
  {
     alert("alphabets only");
	 document.sregister.fname.focus();
	 return false;
   }
	 if(!document.sregister.lname.value.match(/^[a-z A-Z]+$/))
   {
      alert("alphabets only");
 	 document.sregister.lname.focus();
 	 return false;
    }
   if(document.sregister.dob.value=="")
   {
      alert("enter your date of birth");
	 document.sregister.dob.focus();
	 return false;
	}

	if((document.sregister.gender[0].checked==false)&&(document.sregister.gender[1].checked==false))
	{
	   alert("please select the gender");
	   return false;
	 }
	 if(document.sregister.mobile.value=="")
   {
      alert("enter your mobile number");
	 document.sregister.mobile.focus();
	 return false;
	}
	if(isNaN(document.sregister.mobile.value))
    {
     alert("using only numbers");
	 document.sregister.mobile.focus();
	 return false;
   }
   var mobile=document.sregister.mobile.value;
   if(mobile.length!=10)
   {
     alert("mobile number contain 10 digit");
		 document.sregister.mobile.focus();
	 return false;
	}
	if(document.sregister.email.value=="")
   {
      alert("enter the mail address");
	 document.sregister.email.focus();
	 return false;
	}

	if(!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.sregister.email.value)))
	{
		alert("you have entered an invalid email address:");
		return false;
	}
	if(isNaN(document.sregister.pin.value))
		{
		 alert("using only numbers");
	 document.sregister.pin.focus();
	 return false;
	 }

	if (document.sregister.pword.value=="")
	 {
		 alert("provide password");
		 document.sregister.pword.focus();
		 return false;
	 }
	 if(!document.sregister.hname.value.match(/^[a-z A-Z]+$/))
   {
      alert("alphabets only");
 	 document.sregister.hname.focus();
 	 return false;
    }
		
}
</script>
</br>
</br>
<body>
<form name="sregister" id="form" method="POST" action="#" onSubmit="return valid()">
<div class=f2>

<table width="450"height="550"align="center"cellpadding="10">
<tr>
<td colspan="2" align="center"><b><h3>Students Registration</h3></b></td>
</tr>
<tr>
<td width="91"><b>Roll Number</b></td>
<td width="296">
<input type="int" style="color:black;"name="adno" min='1000' max='9999' required onChange="return sAdmNo()" title="only integers"></td>
</tr>

<tr>
<td width="91"><b>First Name</b></td>
<td width="296">
<input type="text" style="color:black;"name="fname" required onChange="return fName()"></td>
</tr>
<tr>
<td width="91"><b>Last Name</b></td>
<td width="296">
<input type="text" style="color:black;"name="lname" required onChange="return lName()"></td>
</tr>
<tr>
<td><b>Date of birth</b></td>
<td>
<input type="date"name="dob" min="1990-01-01" max="2000-01-01" required></td>
</tr>
<tr>
<td><b>Gender</b></td>
<td><input type="radio"name="gender"value="male">
Male
<input type="radio"name="gender"value="female">
Female

</td>
</tr>
<tr>
<td><b>ContactNumber</b></td>
<td>
<input type="tel" name="phone" required onChange="return lPhone()"></td>
</tr>
<td><b>Mobile No</b></td>
<td>
<input type="tel" name="mobile" pattern="[789][0-9]{9}"  required onChange="return sPhone()"></td>
</tr>
</br>
<tr>
<td><b>Email</b></td>
<td>
<input type="email" name="email" required onChange="return sEmail()"></td>
</tr>
<tr>
<td><b>House Name</b></td>
<td>
<input type="text" name="hname" required onChange="return hName()"></td>
</tr>
 <tr>
 <td><b>State</b></td>


									<td><div class="controls">
                                                                            <!--<input type="text" placeholder="Enter your country"  class="input-xlarge" required/>-->
                                                                            <select class="form-control" name="state_select" id="state_select" required/>
                  <option value="-1">select</option>
                           
            <?php
            $q = mysqli_query($con, "SELECT stateid,statename FROM state");
            //var_dump($q);

            while ($row = mysqli_fetch_array($q)) {
                echo '<option value=' . $row['stateid'] . '>' . $row['statename'] . '</option>';
            }
            ?>
              </select></td></td></tr>

<tr>
<td>
<div class="control-group">
<!--<td>DISTRICT</td>-->
									<label class="control-label">District</label><td>
									<div class="controls">
                                                                            <!--<input type="text" placeholder="Enter your district" id="district" name="district" class="input-xlarge" required/>-->
									<select class="form-control" name="district_select" id="district_select" required/>
                        <option value="-1">select</option></select>
                                                                        </div>
								</div></tr></td></td><tr><td><div class="control-group">
									<label class="control-label">City</label><td>
									<div class="controls">
                                                                            <!--<input type="text" placeholder="Enter your town" id="town" name="town" class="input-xlarge" required/>-->
                                                                            <select class="form-control" name="place_select" id="place_select" required/>
                        <option value="-1">select</option></select>
                                                                        </div>
								</div></td></td></tr>
 <tr>
<td><b>Pincode</b></td>
<td>
<input type="int" name="pin" required onChange="return sPin()"></td>
</tr>
<tr>
<td><b>Branch</b></td>
<td>
<input type="text" name="branch" >
</td>
</tr>
<tr>
<td><b>Semester</b></td>
<td>
<label>
          <select name="sem" required>
              <option>s1</option>
              
              <option>s2</option>
			  <option>s3</option> 
			   <option>s4</option>
			 
            </select>
        </label>
</td>
</tr>
<tr>
        <td><b>Password</b><span class="style1">*</span></td>
        <td><label for="pword"></label>
        <input type="password" name="pword" id="pword"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" requiredrequired /></td>
      </tr>
	  <tr>
        <td><b>ConfirmPassword</b><span class="style1">*</span></td>
        <td><label for="cpword"></label>
        <input type="password" name="cpword" id="cpword"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" requiredrequired /></td>
      </tr>



</table>
<br>
<div align="center" >
            <input type="submit" name="submit"  value="Register" class="button"/>
          </div>
</div>

</form>
<script src="jquery-3.2.1.min.js"></script>
<script src="js/validation.js"></script>
<script>
	
      $('body').on('change', '#state_select', function () {
//            alert("countryslected");
            $index = $('#state_select').val();
           
            $.ajax({
            type:'post',
                    url:'get_district.php',
                    data:{index:$index},
                    success:function(response)
                    {
//                        alert(response);
                    console.log(response);
                    $ar = response.split(",");
                           $str = "<option value='-1' disabled hidden selected> </option>";
                            for (var i = 0; i < $ar.length; i++)
                    {
                        $ss=$ar[i].split(':');
                    $str += '<option value='+$ss[0]+'>' + $ss[1] + "</option>";
                    }
                    $('#district_select').html($str);
                }
                    });
                    
    });
                    
                  
          $('body').on('change', '#district_select', function () {
//            alert("countryslected");
            $index = $('#district_select').val();
            $index_id=$('#district_select option selected').val();
           
            $.ajax({
            type:'post',
                    url:'get_town.php',
                    data:{index:$index},
                    success:function(response)
                    {
//                        alert(response);
                    console.log(response);
                    $ar = response.split(",");
                          $str = "<option value='-1' disabled hidden selected> </option>";
                            for (var i = 0; i < $ar.length; i++)
                    {
                        $ss=$ar[i].split(':');
                    $str += '<option value='+$ss[0]+'>' + $ss[1] + "</option>";
                    }
                    $('#place_select').html($str);
                }
                    });
                    
    });
                    
   

$('body').on('change', '#place_select', function () {
//            alert("countryslected");
            $index = $('#place_select').val();
            $index_id=$('#place_select option selected').val();
            $('#place_select option:selected').val();
           
            $.ajax({
            type:'post',
//                    url:'get_town.php',
                    data:{index:$index},
                    success:function(response)
                    {
//                        alert(response);
                    console.log(response);
                    $ar = response.split(",");
                          $str = "<option value='-1' disabled hidden selected> </option>";
                            for (var i = 0; i < $ar.length; i++)
                    {
                        $ss=$ar[i].split(':');
                    $str += '<option value='+$ss[0]+'>' + $ss[1] + "</option>";
                    }
//                    $('#place_select').html($str);
                }
                    });
                    
    });
                        
                        
                        
		</script>		
<br>

    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="293">&nbsp;</td>
  </tr>
</table>

</body>
</html>
