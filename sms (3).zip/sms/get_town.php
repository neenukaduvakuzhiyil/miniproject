<?php

include_once 'conn.php';
if (isset($_POST['index'])) {
    $index = $_POST['index'];
    $q = mysqli_query($con, "SELECT cityid,cityname FROM city where districtid='" . $index . "'");
    //var_dump($q);
    $str = "";
    while ($row = mysqli_fetch_array($q)) {
        
        $str .=$row['cityid'].":" . $row['cityname'] . ",";
        
    }
    echo rtrim($str,",");
}
?>