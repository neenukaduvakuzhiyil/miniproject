<?php

include_once 'conn.php';
if (isset($_POST['index'])) {
    $index = $_POST['index'];
    $q = mysqli_query($con, "SELECT districtid,districtname FROM district where stateid='" . $index . "'");
    //var_dump($q);
    $str = "";
    while ($row = mysqli_fetch_array($q)) {
        
        $str .=$row['districtid'].":" . $row['districtname'] . ",";
        
    }
    echo rtrim($str,",");
}
?>