<?php
include_once("conn.php");


//include_once("config.php");
$id=$_GET['id'];
$result ="SELECT * FROM fee where feeid='$id'";
$result3=mysqli_query($con,$result);
while($row3 = mysqli_fetch_array($result3))
{ 


$s=$row3['amount'];

}

if(isset($_POST['submit']))
{
	
$adno=$_POST['rollno'];
$bank=$_POST["bank"];
//$card=$_POST["card"];
$cvv=$_POST["cvv"];
$amount=$_POST["amount"];
$cardno=$_POST["cardno"];
$holdername=$_POST["holdername"];
//@$reg_id=$_SESSION["reg_id"];
$date		=	date("Y-m-d");
$sql="INSERT INTO `payment`( `amount`, `bank`, `cardno`, `cvv`, `holdername`, `date`,'status') 
VALUES ('$amount','$bank','$cardno','$cvv','$holdername','$date','paid')";
//$sql2="UPDATE `fee` SET `status`='paid' WHERE feeid='$id'";
$result=mysqli_query($con,$sql);
echo '<script type="text/javascript">';
echo 'alert("Successfull.!");';
echo 'window.location.href = "#";';
echo '</script>';
}

?>




<html>
<head>


<style>
.aa{
width:580px;
height:520px;
background-color:Gainsboro ;
margin:0 auto;
margin-top:10px;
margin-left:100px;
padding-top:10px;
padding-left:50px;
border-radius:1px;
-webkit-border-radius:40px;
-o-border-radius:50px;
-moz-border-radius:15px;
color:black;
font-weight:bolder;
box-shadow:inset -4px -4px rgba(0,0,0,0.5);
font-size:18px;
}

.aa input[type="text"] {
    width: 200px;
height:35px;
border:0;
border-radius:5px;
-webkit-border-radius:5px;
-o-border-radius:10px;
-moz-border-radius:5px;
  padding-left:5px;

}
.aa input[type="number"] {
    width: 200px;
height:35px;
border:0;
border-radius:5px;
-webkit-border-radius:5px;
-o-border-radius:5px;
-moz-border-radius:5px;
  padding-left:5px;

}
.aa input[type="submit"] {
    width: 180px;
height:35px;
border:0;
border-radius:5px;
-webkit-border-radius:5px;
-o-border-radius:5px;
-moz-border-radius:5px;
 background-color:white;
font-weight:bolder;

}
</style>
<br>
<h1></h1>

 <table>


    <tr>
  <td>
    <center>
    <img class="one" src="images\bank.jpg" width="449" height="100">

    </center>

<div class="aa">
<form name="myform" action="#" method="post">
<br>
  RollNo:
  <input type="text" name="rollno" readonly value='<?php echo $uname ?> '> </br>
  PAY BY:
<input type="radio" name="card" id="card" value="Credit Card/Debit Card" required/>Credit Card/Debit Card
<input type="radio" name="card" id="card" value="VISA" required />VISA
  <br>
<br>

   Select Bank&nbsp;&nbsp;&nbsp;&nbsp;
    <select name="bank">
  <option value="State Bank Of India">State Bank Of India</option>
   <option value="State Bank Of Travancore">State Bank Of Travancore</option>
  <option value="Axis Bank">Axis Bank</option>
   <option value="Punjab National Bank">Punjab National Bank</option>
</select>
<br>
<br>
Amount&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text"  value="<?php echo $s ;?>"  name="amount" readonly><br>
    <br>
<br>Card Holder&nbsp;&nbsp;
  <input type="text" name="holdername" id="name"   required/>
    <br><br>
    Card number&nbsp;&nbsp;

<input type="text" name="cardno" id="card" maxlength="20"   required/>
        <br><br>

cvv&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="password" name="cvv" placeholder="cvv"  id="cvv" maxlength="3"  required/>
<br>
<br>
Validity&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="date" name="date"  required/>
<br>


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<br>
<table align="center">
<tr>
<td>
<input type="submit" name="submit" value="MAKE PAYMENT" ><br>
</td>
</tr>
</table>
</div>
</form>
<script src="jquery-3.2.1.min.js"></script>
<script src="js/validation.js"></script>

<br>
<br>
</body>
</html>