<?php
include 'conn.php';
session_start();
if(!(isset($_SESSION['uname'])))
{
	header('location:index.php');
}
$apid=$_GET['lid'];
$sql="UPDATE `leave` SET `status1`='denied' WHERE `lid`='$apid' ";
$results=mysqli_query($con,$sql);
if($results>0)
{
	echo "denied";
}
else
echo "cannot posiible";
header('location:leavedetails.php');

?>