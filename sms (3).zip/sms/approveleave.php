<?php
include 'conn.php';
session_start();
if(!(isset($_SESSION['uname'])))
{
	header('location:index.php');
}
$apid=$_GET['lid'];
$sql="UPDATE `leave` SET `status1`='approved' WHERE `lid`='$apid' ";
$results=mysqli_query($con,$sql);
if($results>0)
{
	echo "aprvd";
}
else
echo "cannot aprv";
header('location:leavedetails.php');
?>