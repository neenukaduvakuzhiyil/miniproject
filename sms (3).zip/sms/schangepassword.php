<?php
include 'conn.php';
session_start();
$id=$_SESSION['uname'];
if(isset($_POST['submit']))
{
$uname=$_POST["uname"];
$oldp=$_POST["old"];
$newp=SHA1($_POST["new"]);
$conp=SHA1($_POST["con"]);
$sql="UPDATE `login` SET `password`='$conp' WHERE `username`='$uname'";
//echo $sql;
$result = mysqli_query($con,$sql);
if($result==1)
{
	echo "<script>alert('Password changed')</script>" ;
}
else
{
	echo "<script>alert('failed')</script>" ;
}
}
?>
<!DOCTYPE html>

<html lang="en">
  <head>
    <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
    ====================================================-->

    <!-- Basic Page Needs
    ================================================== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <title>WpF Degree : Home</title>

    <!-- Mobile Specific Metas
    ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/icon" href="img/wpf-favicon.png"/>

    <!-- CSS
    ================================================== -->       
    <!-- Bootstrap css file-->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Font awesome css file-->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- Superslide css file-->
    <link rel="stylesheet" href="css/superslides.css">
    <!-- Slick slider css file -->
    <link href="css/slick.css" rel="stylesheet"> 
    <!-- Circle counter cdn css file -->
    <link rel='stylesheet prefetch' href='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/css/jquery.circliful.css'>  
    <!-- smooth animate css file -->
    <link rel="stylesheet" href="css/animate.css"> 
    <!-- preloader -->
    <link rel="stylesheet" href="css/queryLoader.css" type="text/css" />
    <!-- gallery slider css -->
    <link type="text/css" media="all" rel="stylesheet" href="css/jquery.tosrus.all.css" />    
    <!-- Default Theme css file -->
    <link id="switcher" href="css/themes/default-theme.css" rel="stylesheet">
    <!-- Main structure css file -->
    <link href="style.css" rel="stylesheet">
   
    <!-- Google fonts -->
    <link href='http://fonts.googleapis.com/css?family=Merriweather' rel='stylesheet' type='text/css'>   
    <link href='http://fonts.googleapis.com/css?family=Varela' rel='stylesheet' type='text/css'>    

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </head>
  <body>    

    <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <!--=========== BEGIN HEADER SECTION ================-->
    <header id="header">
      <!-- BEGIN MENU -->
      <div class="menu_area">
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation">  <div class="container">
            <div class="navbar-header">
              <!-- FOR MOBILE VIEW COLLAPSED BUTTON -->
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <!-- LOGO -->
              <!-- TEXT BASED LOGO -->
              <a class="navbar-brand" href="index.html">WpF <span>college</span></a>              
              <!-- IMG BASED LOGO  -->
               <!-- <a class="navbar-brand" href="index.html"><img src="img/logo.png" alt="logo"></a>  -->            
                     
            </div>
             <div id="navbar" class="navbar-collapse collapse">
              <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
                <li class="active"><a href="index.php">Home</a></li>
            
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Register<span class="caret"></span></a>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="studreg.php">Student Register</a></li>
                    <li><a href="teacherreg.php">Teacher Register</a></li>               
                  </ul>
                </li>               
                <li><a href="login.php">Login</a></li>
              </ul>           
            </div><!--/.nav-collapse -->
          </div>     
        </nav>  
      </div>
      <!-- END MENU -->    
    </header>
	
	<script>
function validation()
{
if (document.changepassword.old.value=="")
	 {
		 document.changepassword.old.focus();
		 alert("enter old password");
		 return false;
	 }
if (document.changepassword.new.value=="")
	 {
		 document.changepassword.new.focus();
		 alert("provide a new password");
		 return false;
	 }
if (document.changepassword.con.value=="")
	 {
		 	 alert("provide confirm password");
		 document.changepassword.new.focus();
		 return false;
	 }
	 

	 if (document.changepassword.old.value ==document.changepassword.new.value) {
		 alert("old and new passwords are same");
		 document.changepassword.new.focus();
		 return false;

	 }

if (document.changepassword.new.value!=document.changepassword.con.value)
	 {
		 alert("new password and confirm password are mismatch");
		 document.changepassword.con.focus();

		 return false;
	 }
}

</script>

<body  style="background-image:url(bg6.jpg)">
<div>
<form id="form1" name="changepassword" method="post" action="" onSubmit="validation()">
<br>
<br>
<br>
<table width="300" height="250" align="center">
  <tr>
    <td ><h4>Username:</h4></td>
<td><label for="textfield2"></label>
    <input type="text" name="uname" id="uname" readonly value='<?php echo $id ?> '/></td>
  </tr>
  <br>
  <br>
  <br>
  <tr>
    <td ><h4>OldPassword</h4></td>
<td><label for="textfield2"></label>
    <input type="password" name="old" id="old" required /></td>
  </tr>
  <tr>
    <td><h4>New password</h4></td>
    <td><label for="textfield2"></label>
    <input type="password" name="new" id="new" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" requiredrequired /></td>
  </tr>
  <tr>
    <td><h4>Confirm password</h4></td>
    <td><label for="textfield3"></label>
    <input type="password" name="con" id="con" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" requiredrequired /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="submit" id="button" value="ChangePassword" class="button" />
      
   </td>
  </tr>
</table>

</form>
</div>
<br>
<br>


</body>
<br>
<br>

</body>
</html>
