<?php
include 'conn.php'; //database connection page
//if(!isset($_SESSION["email"])) {
	//header('location:index.php');
//}
if(isset($_POST["submit"])) {
	header('location:book.php');
}
?> 

<!DOCTYPE html>
<!--
Template Name: Lolwork
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html>
<head>
<style>
div.img {
    margin: 15px;
    border: 3px solid #ccc;
    float: left;
    width: 250px;
	background-color:#;
	height:290px;
	border-radius:13px 13px 13px 13px;
}
div.img:hover span:after {
  position: relative;
  opacity: 0;
  top: 0;
  left:980px;
  transition: 0.5s;
}



div.img:hover span{
    border: 1px solid #777;
	padding-right: 0px;
}

div.img:hover span:after{
  opacity: 1;
  right: 0;
}

div.img img {
    height:160px;
	width:250px;
}

div.desc {
    padding: 2px;
    text-align: center;
	font-family:Benguiat Bk BT;
}
.button1 {	width:100px;
	background-color:skyblue;
	border-radius:13px;
	cursor: pointer;
}
</style>

<title>Lolwork | Pages | Gallery</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" href="css/layout1.css" type="text/css" media="all">

</head>
<body id="top">

<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    
    
   
    <nav id="mainav" class="fl_right">
      <ul class="clear">
        <li><a href="teacher.php">Home</a></li>
		
        <li><a class="drop" href="#">Tutorials</a>
          <ul>
			
            <li class="active"><a href="video_view.php">Video view</a></li>
            
            <li><a href="text_view.php">Book View</a></li>
            
          </ul>
        </li>
		
          
       
        
      </ul>
    </nav>
   
  </header>
</div>

<div class="wrapper row2">

</div>

<div class="wrapper row3">
  <main class="hoc container clear"> 

    <div class="content"> 

     <!-- <div id="gallery">-->
        <div>
<div class="content"> 
<figure>
          <header class="heading">Books</header>
		  
		  <?php 
		  include 'conn.php';


$qry="SELECT `pdfid` ,`image`, `name`, `pdfauthor`, `pdf`, `subject` FROM `textb`";
$res=mysqli_query($con,$qry);
$i=0;
while($row=mysqli_fetch_array($res))
{
	$i++;
	if($i % 6==1)
	{
		echo "<tr>";
	}
?>
			<form  method="post">	
									
        	<div class="img">
    				<img src="<?php echo $row['image']?>" alt="Trolltunga Norway" height="300" width="250"><br><br>
  				<div class="desc">
    				<?php echo $row['name']?><br>
					<b>by:  </b><?php echo $row['pdfauthor']?>
   				 
					<center> <a href="viewtext.php?id=<?php echo $row['pdfid']; ?>"> READ MORE</a> </center>
 				 </div>
				 </li>
			</div>
			<!--</div>-->
            </form>
		</td>
 <?php } ?>
		  
		  
          <ul class="nospace clear">
            <li class="one_quarter first">

			</li>
            
          </ul>
         
        </figure>
      </div>
        
    
    </div>
    
    <div class="clear"></div>
  </main>
</div>


<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<!-- IE9 Placeholder Support -->
<script src="../layout/scripts/jquery.placeholder.min.js"></script>
<!-- / IE9 Placeholder Support -->

</body>
</html>