<?php
include 'conn.php';
session_start();
$id=$_SESSION['uname'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Student portal | register</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<link rel="stylesheet" href="css/saps.css" type="text/css">
<script type="text/javascript" src="js/jquery-1.5.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Molengo_400.font.js"></script>
<script type="text/javascript" src="js/Expletus_Sans_400.font.js"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="js/html5.js"></script>
<style type="text/css">.bg, .box2{behavior:url("js/PIE.htc");}</style>
<![endif]-->
</head>
<body id="page2">
<div class="body1">
  <div class="main">
    <!-- header -->
    <header>
      <div class="wrapper">
        <nav>
          <ul id="menu">
            <li><a href="student.php">Home</a></li>
           <li class="dropdown">
      <a href="#" class="dropbtn">Leave</a>
      <div class="dropdown-content">
<a href="applyleave.php">Apply Leave</a>
<a href="leavestatus.php">Leave Status</a></li>
<li class="dropdown">
      <a href="#" class="dropbtn">Tutorials</a>
      <div class="dropdown-content">
<a href="viewvideo.php">View video</a>
  	  <a href="text_view.php">View Text</a></li>
</ul></nav>
        <ul id="icons">
          <li><a href="#"><img src="images/icons1.jpg" alt=""></a></li>
          <li><a href="#"><img src="images/icons2.jpg" alt=""></a></li>
        </ul>
      </div>
      <div class="wrapper">
        <h1><a href="index.php" id="logo">Learn Center</a></h1>
      </div>
      <div id="slogan"> We Will Open The World<span>of knowledge for you!</span> </div>
    </header>
    <!-- / header -->
  </div>
</div>
<div class="body2">
  <div class="main">
    <!-- content -->
    <section id="content">
      <div class="box1">
        <div class="wrapper">
          <article class="col1">
            <div class="pad_left1">
              <h2 class="pad_bot1"><b>Leave Details</b></h2>
            </div>
            
    <!-- content -->
    <!-- footer -->
</br>
<div align="center">
  <table width="600" border="1">
    
    <tr>
     
	  <td>Admission No:</td>
      <td>Date:</td>
      
	   <td>Reason</td>
	    <td>Type</td>
	   <td>Status</td>
      
    </tr>
    <?php
$result=mysqli_query($con,"SELECT  `rollno`, `date`, `reason`, `type`, `status1` FROM `leave` WHERE rollno='$id' " );
while($row=mysqli_fetch_array($result))
{
?>
    <tr>
      
	  <td><?php echo $row["rollno"]?></td>
    <td><?php echo $row["date"]?></td>
    
	    <td><?php echo $row["reason"]?></td>
		  <td><?php echo $row["type"]?></td>
<td><?php echo $row["status1"]?></td>
  
    </tr>
    <?php
 }
 ?>
   </table>
</div>
 
</body>
</html>