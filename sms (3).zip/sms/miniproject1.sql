-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2018 at 07:15 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `miniproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE IF NOT EXISTS `branch` (
`branchid` int(11) NOT NULL,
  `branches` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branchid`, `branches`) VALUES
(1, 'BCA'),
(2, 'MCA REGULAR'),
(3, 'MCA LE'),
(4, 'DDMCA');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `cityid` int(11) NOT NULL,
  `cityname` varchar(15) NOT NULL,
  `districtid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`cityid`, `cityname`, `districtid`) VALUES
(1, 'manarcad', 1),
(2, 'Kanjikuzhi', 1),
(3, 'pala', 1),
(4, 'kanjirapally', 1),
(5, 'pampadi', 1),
(6, 'Muhamma', 2),
(7, 'cherthala', 2),
(8, 'Mavelikara', 2),
(9, 'Ambalapuzha', 2),
(10, 'Haripad', 2),
(11, 'ranni', 4),
(12, 'Konni', 4),
(13, 'Thirualla', 4),
(14, 'Pandalam', 4),
(15, 'Vypin', 3),
(16, 'Thevara', 3),
(17, 'EDapppally', 3),
(18, 'Thiruor', 6),
(19, 'Kuttipuram', 6),
(20, 'Nillambur', 6);

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE IF NOT EXISTS `class` (
`classid` int(11) NOT NULL,
  `classes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contest`
--

CREATE TABLE IF NOT EXISTS `contest` (
`eid` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `venue` varchar(20) NOT NULL,
  `description` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE IF NOT EXISTS `district` (
`districtid` int(11) NOT NULL,
  `districtname` varchar(10) NOT NULL,
  `stateid` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `district`
--

INSERT INTO `district` (`districtid`, `districtname`, `stateid`) VALUES
(1, 'kottayam', 1),
(2, 'alapuzha', 1),
(3, 'Ernakulam', 1),
(4, 'Pathanamth', 1),
(5, 'Kambam', 2),
(6, 'Malapuram', 1);

-- --------------------------------------------------------

--
-- Table structure for table `fee`
--

CREATE TABLE IF NOT EXISTS `fee` (
`feeid` int(11) NOT NULL,
  `branchf` varchar(25) NOT NULL,
  `semf` varchar(20) NOT NULL,
  `ftype` varchar(20) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fee`
--

INSERT INTO `fee` (`feeid`, `branchf`, `semf`, `ftype`, `amount`) VALUES
(1, 'MCALE ', 's1', 'Semester Fee', 25000);

-- --------------------------------------------------------

--
-- Table structure for table `leave`
--

CREATE TABLE IF NOT EXISTS `leave` (
`lid` int(11) NOT NULL,
  `rollno` int(11) NOT NULL,
  `branch` varchar(23) NOT NULL,
  `semester` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `reason` varchar(20) NOT NULL,
  `type` varchar(15) NOT NULL,
  `status1` varchar(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leave`
--

INSERT INTO `leave` (`lid`, `rollno`, `branch`, `semester`, `date`, `reason`, `type`, `status1`) VALUES
(1, 9072, '', '', '2018-01-21', 'Fever', 'FN', 'approved'),
(2, 9086, '', '', '2018-01-21', 'Marriage', 'FN', 'approved'),
(3, 9072, '', '', '2018-01-25', 'Fever', 'FULL DAY', 'approved'),
(4, 6789, '', '', '2018-01-30', 'fever', 'AN', 'approved'),
(5, 9087, '', '', '2018-02-27', 'fever', 'FULL DAY', 'applied'),
(6, 9087, '2018-02-26', '', '2018-02-26', 'fever', 'FN', 'applied'),
(7, 9087, '<br /><b>Notice</b>:  U', '<br /><b>N', '2018-02-26', 'fever', 'FN', 'applied'),
(8, 9087, 'MCALE', 's2', '2018-02-28', 'head ache', 'AN', 'applied');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
`logid` int(11) NOT NULL,
  `password` varchar(100) NOT NULL,
  `username` varchar(10) NOT NULL,
  `role` varchar(10) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`logid`, `password`, `username`, `role`, `status`) VALUES
(1, 'a29c57c6894dee6e8251510d58c07078ee3f49bf', 'admin', '1', 0),
(6, '721ec989b032a6007c31abde0af6250e5e0a4f0d', '6978', '3', 0),
(5, '714c4c6b3cd090f79e4fd5229f5ede54568ef49a', '2001', '3', 0),
(7, 'c8eafeda98f62af119419a2de93738ff577d1102', '9072', '0', 0),
(8, '930e02af4ffb0fb619469f87319e35e0dde1a912', '9086', '0', 0),
(9, 'f4b9cd62fd4263071d2ea03b3a3cb8b3a1b344d3', '8900', '2', 0),
(10, 'Nisha@234', '9001', '2', 0),
(11, '94310a085f7fca7d17b56efe30b0ae9857e21357', '8097', '0', 0),
(12, 'e6c25773baa8dbad38b93966b03e3c969170a081', '8790', '3', 0),
(14, '9f641ec086ab6e87ac4e89bba74bacfea413ecb4', 'class', '3', 0),
(15, '5d03ca625153c7a45dc5c6369d1247cc81e274e7', '9071', '2', 0),
(16, 'ac9276d4232ef1f1d5ccb8ecec7875ada14536c7', '6789', '0', 0),
(17, 'd0e017bcd17aaea0b12cfc52c6e63ef924f3f693', '9087', '0', 0);

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE IF NOT EXISTS `marks` (
`markid` int(11) NOT NULL,
  `rollno` int(11) NOT NULL,
  `etype` varchar(25) NOT NULL,
  `sname` varchar(20) NOT NULL,
  `lname` varchar(12) NOT NULL,
  `subject` varchar(20) NOT NULL,
  `branchs` varchar(15) NOT NULL,
  `semester` varchar(10) NOT NULL,
  `marks` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`markid`, `rollno`, `etype`, `sname`, `lname`, `subject`, `branchs`, `semester`, `marks`) VALUES
(1, 9086, '', 'Tintu', 'Tom', 'DAA', 'MCALE', 's1', 30),
(2, 9072, '', 'Neethu ', 'Das ', 'DAA', 'MCALE', 's1', 45),
(3, 9086, '', 'Tintu', 'Tom', 'DAA', 'MCALE', 's1', 32),
(4, 9072, 'First internal', 'Neethu ', 'Das ', 'ComputerNetworks', 'MCALE', 's1', 25),
(5, 9086, 'First internal', 'Tintu', 'Tom', 'ComputerNetworks', 'MCALE', 's1', 32);

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE IF NOT EXISTS `notes` (
`noteid` int(11) NOT NULL,
  `brnch` varchar(10) NOT NULL,
  `sems` varchar(20) NOT NULL,
  `subject` varchar(25) NOT NULL,
  `desc` varchar(35) NOT NULL,
  `note` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`noteid`, `brnch`, `sems`, `subject`, `desc`, `note`) VALUES
(1, 'MCALE', 's1', '', '', 'note/1518758821'),
(2, 'MCALE', 's1', 'SoftwareEngineering', '', 'note/1518759293'),
(3, 'MCALE', 's1', 'SoftwareEngineering', '', 'note/1518759859'),
(4, 'MCALE', 's1', 'SoftwareEngineering', '', 'note/1518760009');

-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

CREATE TABLE IF NOT EXISTS `reg` (
  `uncod` int(11) NOT NULL,
  `fname` varchar(25) NOT NULL,
  `lname` varchar(25) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `phone` varchar(14) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `email` varchar(23) NOT NULL,
  `hame` varchar(23) NOT NULL,
  `cityid` int(11) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `branch` varchar(15) NOT NULL,
  `semester` varchar(12) NOT NULL,
  `roles` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg`
--

INSERT INTO `reg` (`uncod`, `fname`, `lname`, `dob`, `gender`, `phone`, `mobile`, `email`, `hame`, `cityid`, `pincode`, `branch`, `semester`, `roles`, `status`) VALUES
(2001, 'Binu', 'Mathew', '1981-04-04', 'female', '04812372427', '9087654324', 'binu@gmail.com', 'binubhavan', 15, '234567', 'MCALE', 's1', 3, 0),
(6978, 'Haritha', 'Nair', '1980-01-01', 'female', '04812372427', '7023432112', 'haritha@gmail.com', 'hnhouse', 17, '686019', 'MCALE', 's1', 3, 0),
(9072, 'Neethu ', 'Das ', '1990-01-01', 'female', '', '8765432190', 'neethu@gmail.com', 'nhBhavan', 15, '122343 ', 'MCALE', 's1', 0, 0),
(9086, 'Tintu', 'Tom', '1995-03-30', 'female', '04567382912', '7023432112', 'tintu@gmail.com', 'thhouse', 13, '122343', 'MCALE', 's1', 0, 0),
(8900, 'hsdhab', 'bdjas', '1980-01-01', 'male', '04567382912', '8765432190', 'a@gmaiil.com', 'annhouse', -1, '686097', '', '', 2, 1),
(9001, 'Nisha   ', 'Rajesh   ', '1980-01-01', 'female', '', '9087654329', 'nisha@gmail.com', 'Chennikara   ', 7, '686018  ', '', '', 2, 1),
(8097, 'Elias', 'Joseph', '1999-06-07', 'male', '04812372427', '9562378955', 'elias@gmail.com', 'appoos', 1, '686019', 'MCALE', 's2', 0, 0),
(8790, 'achu   ', 'jacob   ', '1980-01-01', 'female', '  ', '8765432190', 'a@gmaiil.com', 'annhouse   ', 1, '789067 ', 'MCALE', 's2', 3, 0),
(9071, 'Neenu', 'Joseph', '1986-06-26', 'female', '04812372424', '7023432112', 'neenujoseph26@gmail.com', 'kaduvakuzhiyil', 1, '789067', '', '', 2, 0),
(6789, 'Ammu', 'Kurian', '1996-04-04', 'female', ' 04812372323', '9867543212', 'ammu@gmail.com', 'kaduvakuzhiyil', 16, '686019', 'MCA LE', 's2', 0, 0),
(9087, 'Anagha', 'Joseph', '1997-06-18', 'female', '04812345123', '7025263001', 'anagha@gmail.com', 'annhouse', 2, '687907', 'MCALE', 's2', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE IF NOT EXISTS `request` (
`reqid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `stuid` int(11) NOT NULL,
  `message` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `response`
--

CREATE TABLE IF NOT EXISTS `response` (
`resid` int(11) NOT NULL,
  `reqid` int(11) NOT NULL,
  `stuid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `replay` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE IF NOT EXISTS `state` (
  `stateid` int(11) NOT NULL,
  `statename` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`stateid`, `statename`) VALUES
(1, 'kerala'),
(2, 'Thamizhnadu'),
(3, 'Delhi');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
`subid` int(11) NOT NULL,
  `subject` varchar(25) NOT NULL,
  `semester` varchar(11) NOT NULL,
  `branch` varchar(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subid`, `subject`, `semester`, `branch`) VALUES
(1, 'DAA', 's1', 'MCALE'),
(2, 'SoftwareEngineering', 's1', 'MCALE'),
(3, 'ComputerNetworks', 's1', 'MCALE'),
(4, 'webprogramming', 's1', 'MCALE'),
(5, 'DatabaseManagementSystem', 's1', 'MCALE'),
(6, 'ADM', 's2', 'MCALE'),
(7, 'BigData', 's2', 'MCALE'),
(8, 'MobileComputing', 's2', 'MCALE'),
(9, 'MachieLearning', 's2', 'MCALE'),
(10, 'ADBMS', 's2', 'MCALE');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE IF NOT EXISTS `teacher` (
`tid` int(11) NOT NULL,
  `regid` int(11) NOT NULL,
  `empcode` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `time_table`
--

CREATE TABLE IF NOT EXISTS `time_table` (
`tbid` int(11) NOT NULL,
  `branch` varchar(25) NOT NULL,
  `sem` varchar(20) NOT NULL,
  `etype` varchar(29) NOT NULL,
  `timetable` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE IF NOT EXISTS `type` (
`typeid` int(11) NOT NULL,
  `types` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE IF NOT EXISTS `video` (
`videoid` int(11) NOT NULL,
  `image` varchar(75) NOT NULL,
  `subid` int(11) NOT NULL,
  `description` varchar(20) NOT NULL,
  `video` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`videoid`, `image`, `subid`, `description`, `video`) VALUES
(1, 'F:cdrivedownloadsdownload.jpg', 2, 'Bigdata details', 'F:cdrivedownloadsBig Data and Hadoop Quick Introdu'),
(2, 'F:cdrivedownloadsimages (2).jpg', 3, 'bigdata', 'F:cdrivedownloadsHow Big Data Can Influence Decisi'),
(3, 'D:xampphtdocsMainprojectimagesdb.jpg', 7, 'Amazon Elastic block', 'C:Users\neenuDownloadsAmazon Elastic Block Store (EBS) - Block Store on AWS.mp4'),
(4, 'D:xampphtdocsMainprojectimage	hKZHWEYAO.jpg', 3, 'aws', 'C:Users\neenuDownloadsWhat is AWS - Amazon Web Services.mp4'),
(5, 'D:xampphtdocsMainprojectimagescc.jpg', 3, 'AWS', 'C:Users\neenuDownloadsWhat is AWS - Amazon Web Services.mp4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
 ADD PRIMARY KEY (`branchid`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
 ADD PRIMARY KEY (`cityid`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
 ADD PRIMARY KEY (`classid`);

--
-- Indexes for table `contest`
--
ALTER TABLE `contest`
 ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `district`
--
ALTER TABLE `district`
 ADD PRIMARY KEY (`districtid`);

--
-- Indexes for table `fee`
--
ALTER TABLE `fee`
 ADD PRIMARY KEY (`feeid`);

--
-- Indexes for table `leave`
--
ALTER TABLE `leave`
 ADD PRIMARY KEY (`lid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
 ADD PRIMARY KEY (`logid`), ADD UNIQUE KEY `logid` (`logid`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
 ADD PRIMARY KEY (`markid`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
 ADD PRIMARY KEY (`noteid`);

--
-- Indexes for table `reg`
--
ALTER TABLE `reg`
 ADD PRIMARY KEY (`uncod`), ADD UNIQUE KEY `uncod` (`uncod`), ADD UNIQUE KEY `uncod_2` (`uncod`), ADD UNIQUE KEY `uncod_3` (`uncod`), ADD UNIQUE KEY `uncod_4` (`uncod`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
 ADD PRIMARY KEY (`reqid`);

--
-- Indexes for table `response`
--
ALTER TABLE `response`
 ADD PRIMARY KEY (`resid`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
 ADD PRIMARY KEY (`stateid`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
 ADD PRIMARY KEY (`subid`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
 ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `time_table`
--
ALTER TABLE `time_table`
 ADD PRIMARY KEY (`tbid`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
 ADD PRIMARY KEY (`typeid`);

--
-- Indexes for table `video`
--
ALTER TABLE `video`
 ADD PRIMARY KEY (`videoid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
MODIFY `branchid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
MODIFY `classid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `contest`
--
ALTER TABLE `contest`
MODIFY `eid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `district`
--
ALTER TABLE `district`
MODIFY `districtid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `fee`
--
ALTER TABLE `fee`
MODIFY `feeid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `leave`
--
ALTER TABLE `leave`
MODIFY `lid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
MODIFY `logid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
MODIFY `markid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
MODIFY `noteid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
MODIFY `reqid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `response`
--
ALTER TABLE `response`
MODIFY `resid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
MODIFY `subid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `time_table`
--
ALTER TABLE `time_table`
MODIFY `tbid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
MODIFY `typeid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `video`
--
ALTER TABLE `video`
MODIFY `videoid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
