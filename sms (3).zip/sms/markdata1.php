<table width="300" border=1>
<tr>

<td>RollNumber</td>
<td>Name</td>
<td>Subject</td>
<td>Marks</td>
</tr>
<?php
include 'conn.php';

$b=$_POST['index'];
echo $b;
    $results=mysqli_query($con,"select * from marks where subject='". $b."'" );
  while($row=mysqli_fetch_array($results))
  {
?>
<tr>
<td><?php echo $row['rollno'];?></td>
<td><?php echo $row['sname'];?></td>
<td><?php echo $row['subject'];?></td>
<td><?php echo $row['marks'];?></td>

</tr>
<?php

}

?>
</table>
